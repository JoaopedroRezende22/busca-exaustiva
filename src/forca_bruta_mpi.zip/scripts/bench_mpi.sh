#!/usr/bin/env bash
# Mede a versao MPI (e a sequencial, se existir) e grava CSV em resultados/.
#
# Variaveis (opcionais):
#   ESPACOS="30000000 60000000 120000000"   PROCS="2 4 8 12"   REPS=5
#   BLOCOS="1048576"                         (lista -> varredura de bloco)
#   BIN=./build/forca_bruta_mpi   SEQ=./build/forca_bruta
#   MPIRUN_FLAGS="--oversubscribe"  (autodetectado)
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/mpirun_flags.sh

ESPACOS=${ESPACOS:-"30000000 60000000 120000000"}
PROCS=${PROCS:-"2 4 8 12"}
REPS=${REPS:-5}
BLOCOS=${BLOCOS:-"1048576"}
BIN=${BIN:-./build/forca_bruta_mpi}
SEQ=${SEQ:-./build/forca_bruta}

mkdir -p resultados
CSV=resultados/mpi_$(date +%Y%m%d_%H%M%S).csv
echo "versao,espaco,processos,trabalhadores,bloco,repeticao,chave,tempo_s,nucleos,host" > "$CSV"
NUCLEOS=$(nproc)
HOST=$(hostname)

campo() { sed -n "s/.*$1=\([^ ]*\).*/\1/p"; }

if [ -x "$SEQ" ]; then
    for E in $ESPACOS; do for r in $(seq 1 "$REPS"); do
        out=$("$SEQ" "$E")
        echo "seq,$E,1,0,,$r,$(echo "$out" | campo chave),$(echo "$out" | campo tempo),$NUCLEOS,$HOST" >> "$CSV"
        echo "seq   $out"
    done; done
else
    echo "(sequencial nao encontrado em $SEQ; rode 'make seq' para incluir a linha de base)"
fi

for E in $ESPACOS; do for P in $PROCS; do for B in $BLOCOS; do for r in $(seq 1 "$REPS"); do
    out=$(timeout 120 mpirun $MPIRUN_FLAGS -np "$P" "$BIN" "$E" "$B")
    echo "mpi,$E,$P,$((P-1)),$B,$r,$(echo "$out" | campo chave),$(echo "$out" | campo tempo),$NUCLEOS,$HOST" >> "$CSV"
    echo "mpi   bloco=$B $out"
done; done; done; done

echo "CSV gravado em $CSV"

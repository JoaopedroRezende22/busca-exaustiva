#!/usr/bin/env bash
# Define MPIRUN_FLAGS conforme a implementacao de MPI instalada.
# Open MPI: --oversubscribe permite -np maior que o numero de nucleos.
if [ -z "${MPIRUN_FLAGS+x}" ]; then
    if mpirun --version 2>&1 | grep -qi "open mpi\|open-rte\|prte"; then
        MPIRUN_FLAGS="--oversubscribe"
    else
        MPIRUN_FLAGS=""
    fi
fi

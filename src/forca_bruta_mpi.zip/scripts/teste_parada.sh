#!/usr/bin/env bash
# Testes de correcao, parada antecipada e encerramento com mpirun real.
# Qualquer execucao que passe de TIMEOUT segundos conta como TRAVAMENTO.
set -uo pipefail
cd "$(dirname "$0")/.."
source scripts/mpirun_flags.sh
BIN=${BIN:-./build/forca_bruta_mpi}
PROCS=${PROCS:-"1 2 3 4 8 12"}
REPS=${REPS:-3}
TIMEOUT=${TIMEOUT:-60}
falhas=0; total=0

# uso: caso NP ESPACO BLOCO CHAVE_TESTE ESPERADO   (CHAVE_TESTE vazio = alvo padrao)
caso() {
    total=$((total+1))
    out=$(FB_CHAVE_TESTE="$4" timeout "$TIMEOUT" mpirun $MPIRUN_FLAGS -np "$1" "$BIN" "$2" "$3" 2>&1)
    rc=$?
    got=$(echo "$out" | sed -n 's/.*chave=\(-\{0,1\}[0-9]*\).*/\1/p')
    if [ $rc -eq 124 ]; then
        echo "TRAVOU   np=$1 espaco=$2 bloco=$3 chave_teste=$4"; falhas=$((falhas+1))
    elif [ $rc -ne 0 ] || [ "$got" != "$5" ]; then
        echo "FALHOU   np=$1 espaco=$2 bloco=$3 chave_teste=$4 -> rc=$rc: $out"; falhas=$((falhas+1))
    fi
}

for r in $(seq 1 "$REPS"); do for P in $PROCS; do
    # chaves exigidas pelo enunciado (alvo padrao = h(ESPACO/3))
    caso $P  30000000 1048576 ""  10000000
    caso $P  60000000 1048576 ""  20000000
    caso $P 120000000 1048576 ""  40000000
    # parada antecipada / fronteiras
    caso $P 60000000 1048576 0          0          # chave no 1o candidato
    caso $P 60000000 1048576 1048575    1048575    # ultimo do 1o bloco
    caso $P 60000000 1048576 1048576    1048576    # 1o do 2o bloco
    caso $P 60000000 1048576 59999999   59999999   # ultimo candidato
    caso $P  5000000 1048576 4999999    4999999    # acha depois que os blocos acabaram
    caso $P 120000000 40000000 100      100        # interrupcao no meio de bloco grande
    # sem encontro: busca completa, todos encerram
    caso $P 60000000 1048576 60000000   -1
    caso $P     1000 1       5000       -1         # bloco=1: muitas mensagens
    caso $P        1 1048576 0          0          # espaco minimo
done; done

echo "casos=$total falhas=$falhas"
[ $falhas -eq 0 ]

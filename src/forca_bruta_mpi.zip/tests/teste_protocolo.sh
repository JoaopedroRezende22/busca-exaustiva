#!/usr/bin/env bash
# Mesmos casos de scripts/teste_parada.sh, mas com o MPI simulado em threads
# (tests/mockmpi). Nao precisa de MPI instalado. Uso: make teste-protocolo
set -uo pipefail
B=${1:-./build/fb_mock}; REPS=${REPS:-30}; falhas=0; total=0
caso() {
    total=$((total+1))
    out=$(MOCK_NP=$1 FB_CHAVE_TESTE="$4" "$B" "$2" "$3" 2>&1); rc=$?
    got=$(echo "$out" | sed -n 's/.*chave=\(-\{0,1\}[0-9]*\).*/\1/p')
    if [ $rc -ne 0 ] || [ "$got" != "$5" ]; then
        echo "FALHOU np=$1 espaco=$2 bloco=$3 chave_teste=$4 -> rc=$rc: $out"; falhas=$((falhas+1)); fi
}
for r in $(seq 1 "$REPS"); do for P in 1 2 3 4 8 12; do
    caso $P  30000000 1048576 ""  10000000
    caso $P  60000000 1048576 ""  20000000
    caso $P 120000000 1048576 ""  40000000
    caso $P 60000000 1048576 0 0
    caso $P 60000000 1048576 1048575 1048575
    caso $P 60000000 1048576 1048576 1048576
    caso $P 60000000 1048576 59999999 59999999
    caso $P  5000000 1048576 4999999 4999999
    caso $P 120000000 40000000 100 100
    caso $P 60000000 1048576 60000000 -1
    caso $P 1000 1 5000 -1
    caso $P 7 1 6 6
    caso $P 1 1048576 0 0
    caso $P 3000000 65537 1500000 1500000
done; done
echo "casos=$total falhas=$falhas"; [ $falhas -eq 0 ]

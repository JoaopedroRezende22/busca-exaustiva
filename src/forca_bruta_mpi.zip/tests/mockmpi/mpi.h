// MPI minimo em threads, so para testar o protocolo (nao faz parte da entrega).
// MPI_Send e sincrono (pior caso: sem buffer), o que expoe deadlocks que um
// MPI real com envio "eager" poderia esconder.
#pragma once
#include <cstdint>
typedef int MPI_Comm; typedef int MPI_Datatype;
struct MPI_Status { int MPI_SOURCE, MPI_TAG, MPI_ERROR; };
typedef int MPI_Request;
#define MPI_COMM_WORLD 0
#define MPI_UINT64_T 8
#define MPI_INT64_T 8
#define MPI_ANY_SOURCE (-1)
#define MPI_ANY_TAG (-1)
#define MPI_STATUS_IGNORE ((MPI_Status*)0)
#define MPI_STATUSES_IGNORE ((MPI_Status*)0)
int MPI_Init(int*, char***); int MPI_Finalize();
int MPI_Comm_rank(MPI_Comm, int*); int MPI_Comm_size(MPI_Comm, int*);
int MPI_Send(const void*, int, MPI_Datatype, int, int, MPI_Comm);
int MPI_Isend(const void*, int, MPI_Datatype, int, int, MPI_Comm, MPI_Request*);
int MPI_Recv(void*, int, MPI_Datatype, int, int, MPI_Comm, MPI_Status*);
int MPI_Iprobe(int, int, MPI_Comm, int*, MPI_Status*);
int MPI_Waitall(int, MPI_Request*, MPI_Status*);
int MPI_Barrier(MPI_Comm); int MPI_Abort(MPI_Comm, int); double MPI_Wtime();
#define main user_main
int user_main(int, char**);

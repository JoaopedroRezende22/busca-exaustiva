#include "mpi.h"
#undef main
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <list>
#include <memory>
#include <mutex>
#include <thread>
#include <vector>
#include <unistd.h>

struct Msg { int src, tag; std::vector<char> data; bool consumed = false; };
static std::mutex mtx; static std::condition_variable cv;
static int NP = 1;
static std::vector<std::list<std::shared_ptr<Msg>>> caixa;
static std::vector<std::shared_ptr<Msg>> pendentes;   // Isend requests
static thread_local int meu_rank = 0;
static int barreira_cont = 0, barreira_ger = 0;
static const auto LIMITE = std::chrono::seconds(20);

template <class P> static void esperar(std::unique_lock<std::mutex>& lk, P pred, const char* onde) {
    if (!cv.wait_for(lk, LIMITE, pred)) {
        fprintf(stderr, "DEADLOCK: rank %d preso em %s\n", meu_rank, onde);
        fflush(stderr); _exit(99);
    }
}
static bool casa(const Msg& m, int src, int tag) {
    return !m.consumed && (src == MPI_ANY_SOURCE || m.src == src) && (tag == MPI_ANY_TAG || m.tag == tag);
}
static std::shared_ptr<Msg> postar(const void* b, int n, int dst, int tag) {
    auto m = std::make_shared<Msg>(); m->src = meu_rank; m->tag = tag;
    m->data.assign((const char*)b, (const char*)b + n * 8);
    caixa[dst].push_back(m); cv.notify_all(); return m;
}
int MPI_Init(int*, char***) { return 0; }
int MPI_Finalize() { return 0; }
int MPI_Comm_rank(MPI_Comm, int* r) { *r = meu_rank; return 0; }
int MPI_Comm_size(MPI_Comm, int* s) { *s = NP; return 0; }
int MPI_Send(const void* b, int n, MPI_Datatype, int dst, int tag, MPI_Comm) {
    std::unique_lock<std::mutex> lk(mtx); auto m = postar(b, n, dst, tag);
    esperar(lk, [&] { return m->consumed; }, "MPI_Send"); return 0;
}
int MPI_Isend(const void* b, int n, MPI_Datatype, int dst, int tag, MPI_Comm, MPI_Request* r) {
    std::unique_lock<std::mutex> lk(mtx); pendentes.push_back(postar(b, n, dst, tag));
    *r = (int)pendentes.size() - 1; return 0;
}
int MPI_Waitall(int n, MPI_Request* r, MPI_Status*) {
    std::unique_lock<std::mutex> lk(mtx);
    for (int i = 0; i < n; i++) { auto m = pendentes[r[i]]; esperar(lk, [&] { return m->consumed; }, "MPI_Waitall"); }
    return 0;
}
int MPI_Recv(void* b, int n, MPI_Datatype, int src, int tag, MPI_Comm, MPI_Status* st) {
    std::unique_lock<std::mutex> lk(mtx); auto& cx = caixa[meu_rank];
    std::shared_ptr<Msg> achou;
    esperar(lk, [&] {
        // ordem preservada por par: pega a 1a mensagem casada da fila
        for (auto& m : cx) if (casa(*m, src, tag)) { achou = m; return true; }
        return false; }, "MPI_Recv");
    if ((int)achou->data.size() > n * 8) { fprintf(stderr, "truncamento\n"); _exit(98); }
    memcpy(b, achou->data.data(), achou->data.size());
    if (st) { st->MPI_SOURCE = achou->src; st->MPI_TAG = achou->tag; }
    achou->consumed = true; cx.remove(achou); cv.notify_all(); return 0;
}
int MPI_Iprobe(int src, int tag, MPI_Comm, int* flag, MPI_Status* st) {
    std::lock_guard<std::mutex> lk(mtx); *flag = 0;
    for (auto& m : caixa[meu_rank]) if (casa(*m, src, tag)) {
        *flag = 1; if (st) { st->MPI_SOURCE = m->src; st->MPI_TAG = m->tag; } break; }
    return 0;
}
int MPI_Barrier(MPI_Comm) {
    std::unique_lock<std::mutex> lk(mtx); int g = barreira_ger;
    if (++barreira_cont == NP) { barreira_cont = 0; barreira_ger++; cv.notify_all(); }
    else esperar(lk, [&] { return barreira_ger != g; }, "MPI_Barrier");
    return 0;
}
int MPI_Abort(MPI_Comm, int c) { fprintf(stderr, "MPI_Abort(%d)\n", c); fflush(stderr); _exit(c); }
double MPI_Wtime() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
int main(int argc, char** argv) {
    NP = getenv("MOCK_NP") ? atoi(getenv("MOCK_NP")) : 2; caixa.resize(NP);
    std::vector<std::thread> ts; std::vector<int> rc(NP);
    for (int r = 0; r < NP; r++) ts.emplace_back([&, r] { meu_rank = r; rc[r] = user_main(argc, argv); });
    for (auto& t : ts) t.join();
    // nenhuma mensagem pode sobrar em nenhuma caixa ao final
    for (int r = 0; r < NP; r++) if (!caixa[r].empty()) { fprintf(stderr, "SOBROU msg na caixa %d\n", r); return 97; }
    return rc[0];
}

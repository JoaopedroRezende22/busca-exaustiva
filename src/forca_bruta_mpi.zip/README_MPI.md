# Força bruta distribuída com MPI (mestre–trabalhadores)

Versão MPI do Baseline 09. Usa **a mesma `h(k)`, o mesmo alvo `h(ESPACO/3)` e o mesmo espaço `[0, ESPACO)`** da versão sequencial, que fica intacta em `src/seq/forca_bruta.cpp`.

## Arquivos

| Arquivo | Conteúdo |
|---|---|
| `src/mpi/forca_bruta_mpi.cpp` | Implementação MPI, com comentários sobre protocolo, particionamento e encerramento |
| `src/seq/forca_bruta.cpp` | Versão sequencial original, sem alterações |
| `Makefile` | Alvos `mpi` (mpic++ -O3), `seq`, `teste-parada`, `bench`, `teste-protocolo` |
| `Dockerfile` | Ubuntu 24.04 + Open MPI |
| `scripts/teste_parada.sh` | Correção, parada antecipada e detecção de travamento com `mpirun` real |
| `scripts/bench_mpi.sh` | Medições repetidas → `resultados/mpi_<data>.csv` |
| `tests/` | MPI simulado em threads para testar o protocolo sem MPI instalado |

## Uso

```bash
make mpi                                   # build/forca_bruta_mpi
mpirun -np 4 ./build/forca_bruta_mpi 60000000
# espaco=60000000 processos=4 chave=20000000 tempo=<medido> s

mpirun -np 4 ./build/forca_bruta_mpi 60000000 262144   # 2º argumento opcional: tamanho do bloco
```

Com Docker:

```bash
docker build -t forca-mpi .
docker run --rm forca-mpi                                   # -np 4, ESPACO=60000000
docker run --rm forca-mpi make teste-parada                 # testes de parada
docker run --rm -v "$PWD/resultados:/app/resultados" forca-mpi \
       bash -c "make seq && make bench"                     # CSV sai em ./resultados
```

Variáveis do `bench`: `ESPACOS`, `PROCS` (padrão `2 4 8 12`), `REPS` (padrão 5) e `BLOCOS`. Para variar o tamanho do bloco:
`BLOCOS="65536 262144 1048576 4194304" PROCS=4 make bench`.

O `-np` conta **processos**: com `-np 4` são 1 mestre + 3 trabalhadores. Com `-np 1` o rank 0 faz a busca sozinho, na mesma ordem do sequencial. Se `-np` for maior que o número de núcleos (no Docker, por exemplo), o script passa `--oversubscribe` ao Open MPI. Nesse caso os tempos medem disputa de CPU, não paralelismo, e isso deve constar no relatório (a coluna `nucleos` do CSV registra o número de núcleos).

## Protocolo

| Tag | Direção | Significado |
|---|---|---|
| `TAG_PEDIDO` | T → M | Trabalhador livre (primeira mensagem) |
| `TAG_CONCLUIDO` | T → M | Bloco terminado sem achar; vale como novo pedido |
| `TAG_ACHOU` | T → M | Chave encontrada (payload = k) |
| `TAG_TAREFA` | M → T | Bloco `[ini, fim)` |
| `TAG_PARAR` | M → T | Encerrar |
| `TAG_FIM` | T → M | Confirmação: é a última mensagem desse trabalhador |

**Particionamento dinâmico.** O mestre entrega blocos contíguos em ordem crescente a quem pedir primeiro. Um contador único (`proximo`) garante que cada bloco sai exatamente uma vez. Sem encontro, o mestre confere no fim que `proximo == ESPACO`, ou seja, nenhum bloco foi perdido.

**Parada antecipada sem deadlock.**
1. Ao receber `TAG_ACHOU`, o mestre manda `TAG_PARAR` a todos com `MPI_Isend`. Um `MPI_Send` bloqueante aqui poderia travar, porque o trabalhador pode estar ao mesmo tempo num `MPI_Send` para o mestre.
2. O trabalhador checa a parada **entre blocos**, no `MPI_Recv` que espera a próxima tarefa, e **dentro do bloco**, com `MPI_Iprobe` a cada 65.536 candidatos.
3. Ao parar, o trabalhador consome o `TAG_PARAR` e envia `TAG_FIM`. Como o MPI preserva a ordem entre um mesmo par de processos, depois de receber os `P-1` `TAG_FIM` o mestre sabe que não há mais nenhuma mensagem em trânsito. Só então ele conclui os `Isend` (`MPI_Waitall`) e todos chamam `MPI_Finalize`. O mestre nunca termina antes dos trabalhadores.
4. Caso especial: se os blocos já tinham acabado quando alguém acha a chave, quem achou recebe `TAG_PARAR` diretamente, porque não vai pedir mais trabalho. Sem esse tratamento o programa trava; o teste com MPI simulado reproduz esse deadlock.

Nenhuma coletiva é usada durante a troca de mensagens. O único `MPI_Barrier` acontece antes do cronômetro, quando ninguém está enviando nada.

**Tempo.** Medido no mestre com `MPI_Wtime()`. O início é logo após o `MPI_Barrier`; o fim é depois de receber `TAG_FIM` de todos. Inclui distribuição, comunicação, busca e encerramento, e não inclui o `mpirun`, o `MPI_Init` nem o `MPI_Finalize`.

## Tamanho do bloco e das checagens

- **Custo de um candidato:** `h(k)` custa cerca de 1 ns. Medido aqui, o sequencial percorre 20 milhões de candidatos em cerca de 25 ms.
- **Bloco padrão de 2^20 = 1.048.576 candidatos:** representa uma tarefa de cerca de 1 ms, contra alguns microssegundos de ida e volta de mensagem em memória compartilhada. O custo de comunicação fica abaixo de 1%.
  - Com `ESPACO = 60M` são 58 blocos, e a chave (20M) está no bloco 20. Com 11 trabalhadores, cada um pega de 1 a 2 blocos até a chave, o que basta para equilibrar a carga.
  - **Blocos menores** (por exemplo 2^16): mais mensagens e o mestre vira gargalo.
  - **Blocos maiores** (por exemplo 2^24 = 16M): poucos blocos, desbalanceamento, e trabalho desperdiçado além da chave.
- **Checagem a cada 2^16 candidatos:** cerca de 0,1 ms. Uma parada leva no máximo isso para ser percebida dentro de um bloco, e o `MPI_Iprobe` custa menos de 1% desse intervalo.

## Interpretação esperada dos resultados

- **O mestre não testa candidatos.** Por isso `-np 2` (1 trabalhador) deve ficar perto do sequencial ou um pouco pior.
- **Parada antecipada.** Como a chave está em `ESPACO/3`, nem o sequencial percorre o espaço todo. Com P−1 trabalhadores e blocos em ordem, cada um testa cerca de `ESPACO/3 / (P−1)` candidatos, mais no máximo um bloco extra cada um.
- **Execuções curtas.** Os tempos são da ordem de dezenas de milissegundos, então o custo fixo (barreira, primeira rodada de mensagens) pesa bastante. Para ver o speedup com mais clareza, vale incluir também um espaço maior, por exemplo `ESPACOS="... 1200000000"`.

## Testes

```bash
make teste-parada       # com mpirun real: 12 casos × procs {1,2,3,4,8,12} × 3 repetições, timeout 60 s
make teste-protocolo    # sem MPI: mesmos casos em MPI simulado, com MPI_Send síncrono (pior caso)
```

Casos cobertos:
- as três chaves do enunciado;
- a chave no primeiro e no último candidato e nas fronteiras de bloco;
- a chave achada depois de os blocos acabarem;
- a interrupção no meio de um bloco grande;
- a busca completa sem encontro, inclusive com bloco = 1;
- espaço mínimo e argumentos inválidos.

Para isso, a variável **de teste** `FB_CHAVE_TESTE=K` troca o alvo por `h(K)` (com `K >= ESPACO`, a chave não existe no espaço). Ela não deve ser usada nas medições.

## Checklist

- [x] Mesma h(k)/alvo do sequencial
- [x] Mestre + trabalhadores
- [x] Sem blocos perdidos
- [x] Parada sem deadlock
- [x] Finalização de todos os ranks
- [x] Tempos medidos
- [ ] Execução no Docker: rodar `make teste-parada` e `make bench` no ambiente de vocês e anexar o CSV
